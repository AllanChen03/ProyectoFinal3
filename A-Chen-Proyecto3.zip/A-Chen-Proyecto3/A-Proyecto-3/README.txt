----Proyecto 3----

Version Python 3.7.6
Version Pygame 1.9.4 adaptada para 3.7 Idle
PySerial

Ide Arduino

Recuerda descargar las imagenes.

El juego consta de un menu interactivo el cual se accede mediante las teclas,
mencionadas dentro del mismo.

Dentro del mismo juego por cada colision se rebajaran dos de score mientras que 
si consigues la bandera tu puntaje sube 15 PUNTOS!!

A jugar!